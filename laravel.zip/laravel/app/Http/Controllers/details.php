<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\products;

class details extends Controller
{
  public function data()
  {
    $project=products::all();
    //return $project;
    return view('products',compact('project'));

   }
   public function form()
   {
   		return view('productEntry');
   }

   public function formdata()
   {

   		$p=new products();
		$p->ProductId=Request('pid');
		$p->PRoductName=Request('pname');
	    $p->Price=request('price');
		$p->Description=request('comment');
		$p->save();
		return redirect('products');
   }
   public function edit(ProductId)
   {
        $a=products::find(ProductId);
        return view('updateproduct',compact('a'));
   }
   public function update(Request $a,post ProductId)
   {
    $a=products::find('$products');
    $a->ProductId=request('ProductId');
    $a->PRoductName=request('pname');
    $a->Price=request('price');
    $a->Description=request('comment');
    $a->save();
    return redirect('products');
   }

}
