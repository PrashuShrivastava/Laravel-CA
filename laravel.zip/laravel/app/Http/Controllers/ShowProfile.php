<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\employees;

class ShowProfile extends Controller
{
  public function data()
  {
    /*$project=employees::all();
    return $project;

    return view('employees',['']);*/
    $project = DB::table('employees')->get();

       return view('employees', ['employees' => $project]);
       foreach ($project as $project) {
           echo $project->name;
       }
     }
  }
