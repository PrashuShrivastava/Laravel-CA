<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class pagescontroller extends Controller
{
    public function user()
    {
    	return view('user',['Name'=>'Suraj Shah','Section'=>'1617','Registration'=>'11609499']);

    }
    public function form1()
    {
    	return view('collect_data');

    }
    public function formdata1(){
    	return request()->all();
    	//return view('form1')
    }
}
