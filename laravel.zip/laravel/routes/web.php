<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});
 Route::get('/contact',function () {
 	return view('contact');
 });
  Route::get('/user',function () {
 	return view('user');
 });
 Route::get('user/{id}',function ($id) {
 	return 'user'.$id;
 });
 Route::get('posts/{post}/comments/{comment}/',function ($post,$comment) {
 	return 'posts ' .$post.' has comments '.$comment;
 });
 Route::get('posts/{post}/comments/{comment}/',function ($post,$comment) {
 	return 'posts ' .$post.' has comments '.$comment;
 });
 Route::get('Names/{name}/registrations/{registration}/years/{year}/',function ($name,$registration,$year) {
 	return 'Names:-' .$name.'<br>'.'registration number:-'.$registration.'<br>'.'year :-'.$year;
 });
 Route::get('gallery/{name?}',function ($name=NULL) {
 	if($name==null)
 	{
 		return'there is no photos'.' with this name :-'.$name;
 	}
 	else
 	{
 		return'here is your picture '.$name;
 	}
 });

route::get('contact',function(){
	return Response::view('user')
	->header('Content_type','text/plain')
	->header('Content_type','application/pdf')
	->header('Cache-control','no-cache,must-revalidate')
	->header('Expires','sat,26 feb 2019 05:00:00 GMT');

});
route::get('contact',function(){
	return Response::view('contact')

	->header('Content_type','application/pdf')

	->cookie('suraj')
	->header('Expires','sat,26 feb 2019 05:00:00 GMT');

});
Route::get('/user','pagescontroller@user');
Route::get('/employees','ShowProfile@data');
*/
Route::get('/products', function () {
    return view('products');
});
Route::get('/collect_data', function () {
    return view('collect_data');
});
Route::get('/productEntry', function () {
    return view('productEntry');
});
Route::get('/updateproduct', function () {
    return view('updateproduct');
});
Route::post('/products/updateproduct','details@edit');
Route::get('/products/{products}/updateproduct','details@edit');
Route::patch('/products/{products}','details@update');
//------------------------------------------
Route::get('/products','details@data');
Route::get('/form2','details@form');
Route::get('/formdata2','details@formdata');

//Route::get('/collect_data','pagescontroller@formdata');
//Route::get('/collect','details@formdata');

Route::get('/form1','pagescontroller@form1');
Route::post('/formdata1','pagescontroller@formdata1');


Route::get('/form','pagescontroller@form');
Route::get('/formdata','pagescontroller@formdata');
//Route::get('/contact','pagescontroller@contact');
Route::get('/form5','pagescontroller@form5');
Route::post('/formdata5','pagescontroller@formdata5');
