<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{

      public function user()
      {
      	return view('user',['Name'=>'Devinder kaur','Section'=>'1617','Registration'=>'11609499']);
      }

}
