<!DOCTYPE html>
<html>
<head>
	<title>BAZAAR</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<h1>BAZAAR</h1>
		 <p id="slogan">Save Your Money</p>
		 <div class="acess">
     <option>
		<a href="signup" id="signup">SignUp</a>
   <a href="login" id="login">LogIn</a>
	</option>

	 </div>
	</header>
<hr>

	<img  align="centre" src="slide.jpg" id= "image">
	<br>
	<br>
	<div id="products">
		<img src="p.jpg" >
		RS.400/-
		<img src="" >
		RS.500/-
		<img src="" >
		RS.600/-
		<img src="" >
		RS.700/-
		<img src="" >
		RS.800/-
		<img src="" >
		RS.1000/-
	</div>






</body>
</html>
