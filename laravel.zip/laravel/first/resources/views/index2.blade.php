<!DOCTYPE HTML PUBLIC
<html>
<head>
<title>Furniture Shop</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
	<div id="header">																																																																																																										<div class="inner_copy"><a href="http://www.mgwebmaster.com/free-website-builders/">free website builder</a></div>
		<div id="header_insi			<img src="images/header.jpg" alt="setalpm" width="999" height="222" border="0" usemap="#Map" /><br />
			<ul id="menu">
				<li><a href="index" class="but1">Home Page</a></li>
				<li><a href="index2" class="but2_active">About Us</a></li>
				<li><a href="index2" class="but3">News &amp; Events</a></li>
				<li><a href="index2" class="but4">Services</a></li>
				<li><a href="index2" class="but5">My Account</a></li>
				<li><a href="index2" class="but6">Contacts</a></li>
				<li><a href="signup">signup</a></li>

			</ul>
		</div>
	</div>
	<div id="wrapper">
		<div id="content_inside">
			<div id="sidebar">
				<img src="images/title1.gif" alt="" width="174" height="30" /><br />
				<ul id="list">
					<li class="color"><a href="#">Illum secundum</a></li>
					<li><a href="#">Tamen causa ut diam</a></li>
					<li class="color"><a href="#">Appellatio vel hos autem</a></li>
					<li><a href="#">Consequat</a></li>
					<li class="color"><a href="#">Nibh valde tincidunt</a></li>
					<li><a href="#">Illum secundum</a></li>
					<li class="color"><a href="#">Appellatio vel</a></li>
					<li><a href="#">Illum secundum</a></li>
					<li class="color"><a href="#">Nibh valde</a></li>
					<li><a href="#">Consequat</a></li>
					<li class="color"><a href="#">Nibh valde tincidunt</a></li>
					<li><a href="#">Appellatio vel</a></li>
					<li class="color"><a href="#">Illum secundum</a></li>
					<li><a href="#">Consequat</a></li>
					<li class="color"><a href="#">Appellatio vel</a></li>
					<li><a href="#">Illum secundum</a></li>
					<li class="color"><a href="#">Nibh valde</a></li>
				</ul>
			</div>
			<div id="main_block" class="style1">
				<div id="item">
					<h4>Name Product</h4><br />
					<div class="big_view">
						<img src="images/photo.jpg" alt="" width="311" height="319" /><br />
						<span>$99</span>
					</div>
					<div class="scroll">
						<a href="#"><img src="images/pic1.jpg" alt="" width="62" height="62" /></a>
						<a href="#"><img src="images/pic2.jpg" alt="" width="62" height="62" /></a>
						<a href="#"><img src="images/pic3.jpg" alt="" width="62" height="62" /></a>
						<a href="#"><img src="images/pic4.jpg" alt="" width="62" height="62" /></a>
						<a href="#"><img src="images/pic5.jpg" alt="" width="62" height="62" /></a>
						<a href="#"><img src="images/pic6.jpg" alt="" width="62" height="62" /></a>
					</div>
				</div>
				<div class="description">
					<p>
						<strong>Illum secundum exerci</strong><br />
						erat plaga illum, enim, venio. Tamen causa ut diam torqueo sagaciter inhibeo si quae exerci lobortis. Appellatio vel hos autem, ludus luptatum mauris ratis jugis interdico. Gilvus consequat abico demoveo lenis validus typicus ut commodo. Consequat, eu voco cui eros, euismod quis illum, commodo. Nibh valde tincidunt ex quae ratis meus neo aliquam. Appellatio vel hos autem, ludus luptatum mauris ratis jugis interdico. Gilvus consequat abico demoveo lenis validus typicus ut commodo. Consequat, eu voco cui eros, euismod quis illum, commodo. Nibh valde tincidunt ex quae ratis meus neo aliquam.
					</p>
					<p>
						<a href="#" class="view">View</a><a href="#" class="buy">Buy this Product</a>
					</p>
				</div>
			</div>
		</div>
	</div>
	<div id="footer">
		<div id="footer_inside">
			<ul class="footer_menu">
				<li><a href="index">Home Page</a>|</li>
				<li><a href="index2">About Us</a>|</li>
				<li><a href="index2">News &amp; Events</a>|</li>
				<li><a href="index2">Services</a>|</li>
				<li><a href="index2">My Account</a>|</li>
				<li><a href="index2">Contacts</a></li>
			</ul><br /><br />
			<p>Copyright &copy;. All rights reserved. Design by <a href="http://www.bestfreetemplates.info" target="_blank" title="Best Free Templates">BFT</a></p>
		</div>
	</div>
    <map name="Map">
       <area shape="rect" coords="78,45,312,119" href="index.html">
       <area shape="poly" coords="670,87,719,78,727,123,677,130" href="#">
       <area shape="poly" coords="776,124,818,152,793,189,751,160" href="#">
       <area shape="poly" coords="834,52,885,61,878,105,828,96" href="#">
	</map>
</body>
</html>
