suraj kumar
welcome,<?php echo e($Name); ?>,<?php echo e($Section); ?>,<?php echo e($Registration); ?>;