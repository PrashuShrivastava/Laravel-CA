<!DOCTYPE html>
<html>
<head>
	<style>
		td
		{
			background-color:#282C34;
			color:#456E97;
		}
	</style>

</head>
<body>
	<ul>

		<?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<li> <?php echo e($p->ProductId); ?></li>
		<li> <?php echo e($p->PRoductName); ?></li>
		<li> <?php echo e($p->Price); ?></li>
		<li> <?php echo e($p->Description); ?></li>
  <hr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<br>

	</ul>

</body>
</html>
