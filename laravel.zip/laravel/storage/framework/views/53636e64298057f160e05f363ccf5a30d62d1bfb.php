updateproduct.blade.php

/*colllect data from user and put it in table from form and display it on a display it on a view
fname,last name,desc box;route,when when ever user enter data it should be dipalyed back on particular view. */
<!DOCTYPE html>
<html>
<head>
	<title>data dedo</title>
<style>
	body{
		background-color: #6D6E6A;
	}
  div{
  	margin-top: 150px;
    display:inline-block;
    margin-left: 525px;
    color: #99A0AF;
        background-color:#2D2D2D ;
        padding: 20px;
        border-radius: 4px;

  }
  input{
        margin-left: 20px;
        background-color:#4B121F;
  }
  textarea{
  	 margin-left: 20px;
        background-color:#4B121F;
  }
  button{
        float: right;
          background-color:#4B121F;
          color: #99A0AF;
  }
  </style>
</head>
<body>
     <div>
  <form method="POST" action="/products/<?php echo e($products->ProductId); ?>/edit">
  <h1 align="center"> SUBMIT DETAIL</h1>
  	<?php echo e(csrf_field()); ?>

  	<?php echo e(method_field('PATCH')); ?>

     <span>ID</span>
     <input type="number" name="ProductId" placeholder="id"><br>
    <label for="ProductName"><b>Product Name</b></label>
    <br>
     <input type="text" placeholder="Enter Product name" name="pname" required>
  <br>
     <label for="Price"><b>Price</b></label><br>

     <input type="text" placeholder="Enter Price" name="price" required>
     <br>

   <label for="comment"><b>Comment</b></label><br>
    <textarea name="comment" placeholder="comment"></textarea>
    <br>
         <button type="submit"  name="submit" onclick="myfirst" align="center">Register</button>

   </form>
 </div>

</body>

</html
