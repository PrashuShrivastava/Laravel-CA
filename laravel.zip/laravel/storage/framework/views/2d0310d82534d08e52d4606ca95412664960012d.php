/*colllect data from user and put it in table from form and display it on a display it on a view
fname,last name,desc box;route,when when ever user enter data it should be dipalyed back on particular view. */
<!DOCTYPE html>
<html>
<head>
	<title>data dedo</title>
<style>
	body{
		background-color: #6D6E6A;
	}
  div{
  	margin-top: 150px;
    display:inline-block;
    margin-left: 525px;
    color: #99A0AF;
        background-color:#2D2D2D ;
        padding: 20px;
        border-radius: 4px;

  }
  input{
        margin-left: 20px;
        background-color:#4B121F;
  }
  textarea{
  	 margin-left: 20px;
        background-color:#4B121F;
  }
  button{
        float: right;
          background-color:#4B121F;
          color: #99A0AF;
  }
  </style>
</head>
<body>
     <div>
  <form method="post" action="formdata1"> 
  	{{csrf_field()}
  <h1 align="center"> SUBMIT DETAIL</data
    <label for="fname"><b>First Name</b></label>
    <br>
     <input type="text" placeholder="Enter Firstname" name="fname" required>
     <br>

    <label for="lname"><b>Last Name</b></label>
    <br>
     <input type="text" placeholder="Enter Lastname" name="lname" required>
  <br>
     <label for="email"><b>Email</b></label><br>

     <input type="text" placeholder="Enter Email" name="email" required>
     <br>

   <label for="comment"><b>Comment</b></label><br>
    <textarea name="comment" placeholder="comment"></textarea>
    <br>
         <button type="submit"  name="submit" onclick="myfirst" align="center">Register</button>

   </form>
 </div>

</body>

</html


