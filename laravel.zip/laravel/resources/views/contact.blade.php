<h1>contact us</h1>
<form>
	FirstName
	<input type="text" name="first" placeholder="first name">
	<br>
	SecondName
	<input type="text" name="second" placeholder="Second name">
	<br>
	Email
	<input type="email" name="email" placeholder="Email">
	<br>
	Password
	<input type="Password" name="Password" placeholder="Password">
	<br>
	Confirm- password
	<input type="password" name="Confirmpassword">
	<br>
	<Button align="right">Submit</Button>
</form>