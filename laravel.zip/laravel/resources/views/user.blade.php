suraj kumar
welcome,{{$Name}},{{$Section}},{{$Registration}};