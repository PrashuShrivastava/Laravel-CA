<!DOCTYPE html>
<html>
<head>
	<style>
		td
		{
			background-color:#282C34;
			color:#456E97;
		}
	</style>

</head>
<body>
	<ul>

		@foreach($project as $p)

		<li> {{$p->ProductId}}</li>
		<li> {{$p->PRoductName}}</li>
		<li> {{$p->Price}}</li>
		<li> {{$p->Description}}</li>
  <hr>
		@endforeach
		<br>

	</ul>

</body>
</html>
